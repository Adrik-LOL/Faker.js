var Faker = require('../lib');
var faker = new Faker({ locale: 'en_NG', localeFallback: 'en' });
faker.locales['en_NG'] = require('../lib/locales/en_NG');
faker.locales['en'] = require('../lib/locales/en');
module['exports'] = faker;
