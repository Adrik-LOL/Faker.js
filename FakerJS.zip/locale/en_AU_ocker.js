var Faker = require('../lib');
var faker = new Faker({ locale: 'en_AU_ocker', localeFallback: 'en' });
faker.locales['en_AU_ocker'] = require('../lib/locales/en_AU_ocker');
faker.locales['en'] = require('../lib/locales/en');
module['exports'] = faker;
