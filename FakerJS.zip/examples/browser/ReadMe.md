`index.html` contains an example that will require faker with **all** locales.

If you need to use a single locale, you can require it directly as a stand-alone pack from the `/locales` folder here.